/*****************************************************************
 *
 *	Date: 08 July 2013
 *	@author Paul Byrne
 *
 *	Version 1 - Codebreaker game
 *
 *****************************************************************/

import java.util.Scanner;

class App
{
	public static void main(String args[])
	{
		App anApp = new App();
	}
		
	// declare variables
	StringBuffer codePatchToGuess;
	String codePatchToString;
	private String guessString;
	int numberOfLives = 8;
	int livesLeft;
	boolean tryAgain;
	private char theLetterIn;
	
	// declare objects
	private	Scanner someInput;
	private	String theUsersInput;
	
	
	public App()
	{
		
		// declare object
		CodePatchGenerator theCodePatchGenerator;
		
		// create object
		theCodePatchGenerator = new CodePatchGenerator();
		this.someInput = new Scanner(System.in);
		
		codePatchToGuess = theCodePatchGenerator.getColour();
		codePatchToString = codePatchToGuess.toString();
		
		livesLeft = numberOfLives;
		playBoard();
	}
	
	private void playBoard()
	{
        do
        {		
        	
        	playGame();

			this.tryAgain = false;
			System.out.print("\n Play again (Y/N): ");
			this.theUsersInput = this.someInput.nextLine();

			// we get a String in, we only want the first character
			// a String is like an array, the first position starts at 0
			// theLetterIn is of type char

			this.theLetterIn = this.theUsersInput.charAt(0);

			//now comparing two characters
			System.out.println(theLetterIn);
			if( (this.theLetterIn == 'Y') || ( this.theLetterIn == 'y') )
			{
				this.tryAgain = true;
			}
			System.out.println(tryAgain);
       	
        }
        while(this.tryAgain);

	}//EOM-playBoard()
	
	private void playGame() {
	
		this.livesLeft = this.numberOfLives;
		
		// declare variables
		String userString;
	
		while (livesLeft > 0) {
		
		// Getting the users Input
			System.out.println(livesLeft + " Lives Left!");
			System.out.print("Enter a 4 character sequence from ROYGBIV or 0(zero) to exit ");
		
			this.theUsersInput = this.someInput.nextLine();
		
			// CHECK for 0(zero) in user input
			if (theUsersInput.contains("0")) {
				System.out.println("You entered 0(zero) to exit");
				System.exit(0);
			}	
			// END CHECK for 0(zero) in user input
	
			//take the first 4 characters out of any string entered
			userString = this.theUsersInput.substring(0,4);

			//convert character to lowercase before start compars
			this.guessString = userString.toUpperCase();
		
		// END getting the users Input		
	
			// COMPARE the users guess to the code patch
			if (guessString.equals(codePatchToString)) {
				System.out.println("YOU WIN, do you want to play again (Y/N)? ");
			}
			else {
				livesLeft = livesLeft - 1;
				System.out.println("Incorrect Guess");
			}
		}	// END while (livesLeft > 0) LOOP
	}
}