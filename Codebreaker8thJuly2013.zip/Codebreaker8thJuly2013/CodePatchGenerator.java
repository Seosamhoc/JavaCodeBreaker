class CodePatchGenerator {

private char [] allowedColours = {'R','O','Y','G','B','I','V'};

public CodePatchGenerator()
	{
		//no init to do in this constructor
	} // End of CodePatchGenerator() CONSTRUCTOR

public StringBuffer getColour() {

	StringBuffer colourPatch = new StringBuffer();
	
	// Create the CodePatch using 4 randomly generated letters from allowedColours[] ARRAY
	for (int i = 0; i < 4; i++) {
		colourPatch.append(this.allowedColours[(int) (Math.random() * 7)]);
	}
	// Return CodePatch to App.java
	return colourPatch;
	
} // End of getColour() METHOD

}
